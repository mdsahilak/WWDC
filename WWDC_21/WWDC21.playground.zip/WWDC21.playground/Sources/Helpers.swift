import Foundation

// Just a Helper Function to Beautify Console Output
public func consoleLineBreak(_ heading: String ) {
    print("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
    print(heading)
    print("- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -")
}
